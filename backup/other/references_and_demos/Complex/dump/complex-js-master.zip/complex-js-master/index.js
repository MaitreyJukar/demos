module.exports = require('./lib/complex.min');
